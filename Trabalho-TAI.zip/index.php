<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php $carro = array();

$carro[] = " Uno, Fiat, prata, 4, 2018";
$carro[] = "Fiesta, Ford, preto, 2, 2016";
$carro[] = "Doblo, Fiat, verde, 4, 2013";
$carro[] = "Celta, GM, preto, 2, 2012";
$carro[] = "March, Nissan, prata, 2, 2016";
$carro[] = "Cobalt, GM, branco, 2, 2012";
$carro[] = "Ranger, Ford, prata, 4, 2018";
$carro[] = "Trail Blazer, branco, GM, 4, 2020";
$carro[] = "Ecosport, Ford, preto, 4, 2018";
$carro[] =  "Tucson, Hyundai, vinho, 4, 2020";

echo "<pre>";
print_r($carro);
echo "</pre>";

$carro_modelo0=array('Uno, 2018');
$carro_modelo1=array('Fiesta, 2016');
$carro_modelo2=array('Doblo, 2013');
$carro_modelo3=array('Celta, 2012');
$carro_modelo4=array('March, 2016');
$carro_modelo5=array('Cobalt, 2012');
$carro_modelo6=array('Ranger, 2018');
$carro_modelo7=array('Trail Blazer, 2020');
$carro_modelo8=array('Ecosport, 2018');
$carro_modelo9=array('Tucson, 2020');
$modelo=array_merge($carro_modelo0, $carro_modelo1, $carro_modelo2, $carro_modelo3, $carro_modelo4, $carro_modelo5, $carro_modelo6, $carro_modelo7,$carro_modelo8, $carro_modelo9);

echo "<pre>";
print_r($modelo);
echo "</pre>";

$carro_prata0=array('Uno, Fiat, prata, 4, 2018');
$carro_prata1=array('March, Nissan, prata, 2, 2016');
$carro_prata2=array('Ranger, Ford, prata, 4, 2018');
$prata=array_merge($carro_prata0, $carro_prata1, $carro_prata2);

echo "<pre>";
print_r($prata);
echo "</pre>";

$carro_porta0=array('prata, 4');
$carro_porta1=array('preto, 2');
$carro_porta2=array('verde, 4');
$carro_porta3=array('preto, 2');
$carro_porta4=array('prata, 2');
$carro_porta5=array('branco, 2');
$carro_porta6=array('prata, 4');
$carro_porta7=array('branco, GM, 4,');
$carro_porta8=array('preto, 4');
$carro_porta9=array('vinho, 4');
$modelo=array_merge($carro_porta0, $carro_porta1, $carro_porta2, $carro_porta3, $carro_porta4, $carro_porta5, $carro_porta6, $carro_porta7,$carro_porta8, $carro_porta9);

echo "<pre>";
print_r($portas);
echo "</pre>";


$carro_ford0=array('Fiesta, Ford, preto, 2, 2016');
$carro_ford1=array('Ranger, Ford, prata, 4, 2018');
$carro_ford2=array('Ecosport, Ford, preto, 4, 2018');
$ford=array_merge($carro_ford0, $carro_ford1, $carro_ford2);

echo "<pre>";
print_r($ford);
echo "</pre>";

$carro_ano0=array('Uno, Fiat, prata, 4, 2018');
$carro_ano1=array('Fiesta, Ford, preto, 2, 2016');
$carro_ano2=array('March, Nissan, prata, 2, 2016');
$carro_ano3=array('Ranger, Ford, prata, 4, 2018');
$carro_ano4=array('Trail Blazer, branco, GM, 4, 2020');
$carro_ano5=array('Ecosport, Ford, preto, 4, 2018');
$carro_ano6=array('Tucson, Hyundai, vinho, 4, 2020');
$ano=array_merge($carro_ano0, $carro_ano1, $carro_ano2, $carro_ano3, $carro_ano4, $carro_ano5, $carro_ano6,);

echo "<pre>";
print_r($ano);
echo "</pre>";

?> 
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>