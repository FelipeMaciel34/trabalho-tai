<?php 

$str = 'maciel';

$str2 =  str_replace([',','a'],[';','?'],$str);
$str = str_replace('a', '?', $str);
$str = str_replace('e', '?', $str); 
$str = str_replace('i', '?', $str);
$str = str_replace('o', '?', $str);
$str = str_replace('u', '?', $str);
$str = str_replace('A', '?', $str);
$str = str_replace('E', '?', $str);
$str = str_replace('I', '?', $str);
$str = str_replace('O', '?', $str);
$str = str_replace('U', '?', $str);
echo $str;

?> 
  